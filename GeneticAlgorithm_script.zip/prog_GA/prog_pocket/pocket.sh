#!/bin/bash
perl /home/jxliu/ldata2/GA/prog_GA/pocket1.pl *.pdb;
perl /home/jxliu/ldata2/GA/prog_GA/pocket2.pl output1;
perl /home/jxliu/ldata2/GA/prog_GA/pocket3.pl output3;

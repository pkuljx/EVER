#!/bin/bash

for ((a=0;a<=999;a++));do
    cp -rf /home/lhlai_pkuhpc/lustre1/jxliu/genetic_algorithm/pre_sequence/sequence/abl.fasta $a.seq;
done
